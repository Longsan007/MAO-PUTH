
import React, { useState, useEffect } from "react";
import { ICON_LINKS } from "@/utils/profileIconLinks";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";

const PROFILE_IMAGE = "/profile-highres.jpg"; // Place your real image in public/ or use placeholder

const QUOTES = [
  "កូដគឺជាសិល្បៈដែលនាំអោយការច្នៃប្រឌិតក្លាយជាការពិត។",
  "ការសរសេរកូដគឺសិល្បៈនៃការរស់នៅសម្រាប់អ្នកវ័យថ្មី។",
  "បច្ចេកវិទ្យាអាចបង្ហាញមកវិញនូវរូបភាពនៃប្រពៃណីខ្មែរ។",
  "ចូរអភិវឌ្ឍខ្លួនឯងដូចសម្ភារៈនៅវិមានអង្គរ។",
  "ការអភិវឌ្ឍកម្មវិធីគឺការសសេរ​ព្រេងនិទានសម្រាប់អនាគត។",
];

const GALLERY_IMAGES = [
  {
    src: "https://images.unsplash.com/photo-1472396961693-142e6e269027?auto=format&fit=crop&w=600&q=80",
    alt: "វិមានអង្គរវត្ត",
    caption: "សំណង់ប្រាសាទអង្គរវត្ត"
  },
  {
    src: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80",
    alt: "កុំព្យូទ័រនិងកូដ",
    caption: "ការអភិវឌ្ឍបច្ចេកវិទ្យា"
  },
  {
    src: "https://images.unsplash.com/photo-1605810230434-7631ac76ec81?auto=format&fit=crop&w=600&q=80",
    alt: "ការងារក្រុម",
    caption: "ការងារជាក្រុម"
  }
];

export default function ProfileSection() {
  const [quoteIndex, setQuoteIndex] = useState(0);
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    const interval = setInterval(
      () => setQuoteIndex((i) => (i + 1) % QUOTES.length),
      10000 // 10 seconds for quote rotation
    );
    
    // Image gallery rotation
    const imageInterval = setInterval(
      () => setActiveImage((i) => (i + 1) % GALLERY_IMAGES.length),
      15000 // 15 seconds for gallery rotation
    );
    
    return () => {
      clearInterval(interval);
      clearInterval(imageInterval);
    };
  }, []);

  return (
    <header className="w-full relative flex flex-col items-center justify-center py-12 bg-cover bg-center
    transition-colors duration-700"
      style={{
        backgroundImage:
          "url('/patterns/khmer-pattern.svg'), linear-gradient(to bottom, rgba(250,242,225,0.8) 40%, transparent 100%)",
        backgroundBlendMode: "overlay",
      }}
    >
      {/* Angkor silhouette (light) or gold-gradient (dark) */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="w-full h-full mix-blend-multiply hidden dark:block"
          style={{
            background:
              "linear-gradient(135deg, #1f2b43 60%, #d4af37 100%)"
          }}
        />
        <img
          src="/patterns/khmer-pattern.svg"
          alt=""
          className="w-full h-full absolute left-0 top-0 object-cover opacity-10 hidden md:block"
        />
        <img
          src="https://images.unsplash.com/photo-1472396961693-142e6e269027?auto=format&fit=crop&w=1200&q=80"
          alt="Angkor Wat"
          className="w-full h-full object-cover opacity-30 block dark:hidden"
        />
      </div>

      {/* Profile Photo with Khmer pattern border */}
      <div className="relative z-10 mb-4 mt-6">
        <div className="khmer-pattern-border rounded-full p-2 bg-background shadow-xl transition-all duration-500 hover:scale-105"
          style={{ width: 196, height: 196 }}
        >
          <img
            src={PROFILE_IMAGE}
            alt="ជា សុភា"
            className="profile-pic w-44 h-44 object-cover rounded-full shadow-lg"
            style={{
              border: "5px solid #d4af37",
              boxShadow: "0 0 10px rgba(0,0,0,0.15)",
            }}
          />
        </div>
      </div>
      <h1 className="text-3xl md:text-4xl font-bold text-center mb-2 font-khmer z-10 mt-2"
        style={{ fontFamily: "'Kantumruy Pro', sans-serif", letterSpacing: "0.01em" }}
      >
        ឈ្មោះ: ជា សុភា
      </h1>
      <p className="text-lg md:text-xl text-center z-10 font-khmer"
        style={{ color: "#d4af37", fontFamily: "'Kantumruy Pro', sans-serif" }}
      >
        កម្មវិធីវិទ្យាសាស្ត្រច្នៃប្រឌិត | Creative Software Engineer
      </p>
      <div className="flex justify-center items-center mt-4 z-10">
        <TooltipProvider>
          {ICON_LINKS.map(({ href, icon: Icon, label }) => (
            <Tooltip key={label}>
              <TooltipTrigger asChild>
                <a
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mx-2 icon-style transition-transform duration-200 hover:scale-125"
                  aria-label={label}
                  style={{ color: "#1f2b43" }}
                >
                  <Icon className="w-7 h-7" />
                </a>
              </TooltipTrigger>
              <TooltipContent>
                <p>{label}</p>
              </TooltipContent>
            </Tooltip>
          ))}
        </TooltipProvider>
      </div>
      <div className="w-full flex justify-center mt-6 mb-2 z-10">
        <p
          key={quoteIndex}
          className="font-khmer text-base md:text-lg italic text-center px-4 max-w-xl animate-fade-in transition-opacity"
          style={{
            fontFamily: "'Kantumruy Pro', sans-serif",
            color: "#a62d38",
            minHeight: "2.5rem",
            transition: "opacity 0.5s",
          }}
        >
          {QUOTES[quoteIndex]}
        </p>
      </div>
      
      {/* Image Gallery */}
      <div className="mt-8 z-10 w-full max-w-3xl px-4">
        <h3 className="text-xl font-bold font-khmer mb-4 text-center" style={{ color: "#d4af37" }}>
          រូបភាពទាំងអស់
        </h3>
        <div className="relative overflow-hidden rounded-lg shadow-lg h-60 md:h-80">
          {GALLERY_IMAGES.map((image, index) => (
            <div 
              key={image.src} 
              className={`absolute inset-0 transition-opacity duration-1000 ${index === activeImage ? 'opacity-100' : 'opacity-0'}`}
            >
              <img 
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 p-2 text-center">
                <p className="text-white font-khmer text-sm">{image.caption}</p>
              </div>
            </div>
          ))}
          
          {/* Navigation dots */}
          <div className="absolute bottom-12 left-0 right-0 flex justify-center gap-2">
            {GALLERY_IMAGES.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveImage(index)}
                className={`w-2 h-2 rounded-full ${activeImage === index ? 'bg-khmer-gold' : 'bg-white bg-opacity-50'}`}
                aria-label={`រូបភាព ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}
