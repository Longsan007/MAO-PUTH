
import React from "react";
import { Facebook, Linkedin, MessageCircle } from "lucide-react";
import { Link } from "react-router-dom";

const Footer: React.FC = () => {
  return (
    <footer className="bg-background border-t border-khmer-gold/20 py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center">
          <p className="text-center mb-4 max-w-2xl text-sm md:text-base">
            "ការអភិវឌ្ឍន៍បច្ចេកវិទ្យាគឺការរក្សាប្រពៃណីខ្មែរយ៉ាងប្រណិតក្នុងសតវត្សថ្មី"
          </p>
          
          <div className="flex space-x-4 mb-4">
            <a 
              href="#" 
              className="p-2 rounded-full bg-background border border-khmer-gold/30 hover:bg-khmer-gold/10 transition-colors"
              aria-label="Facebook"
            >
              <Facebook className="h-5 w-5" />
            </a>
            <a 
              href="#" 
              className="p-2 rounded-full bg-background border border-khmer-gold/30 hover:bg-khmer-gold/10 transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin className="h-5 w-5" />
            </a>
            <a 
              href="#" 
              className="p-2 rounded-full bg-background border border-khmer-gold/30 hover:bg-khmer-gold/10 transition-colors"
              aria-label="Telegram"
            >
              <MessageCircle className="h-5 w-5" />
            </a>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4 text-sm mb-4">
            <Link to="/" className="hover:text-khmer-gold">ទំព័រដើម</Link>
            <Link to="/about" className="hover:text-khmer-gold">អំពីខ្ញុំ</Link>
            <Link to="/skills" className="hover:text-khmer-gold">ជំនាញរបស់ខ្ញុំ</Link>
            <Link to="/projects" className="hover:text-khmer-gold">គម្រោងរបស់ខ្ញុំ</Link>
            <Link to="/blog" className="hover:text-khmer-gold">ប្លក់បុគ្គលិក</Link>
            <Link to="/contact" className="hover:text-khmer-gold">ទំនាក់ទំនងខ្ញុំ</Link>
          </div>
          
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} អ្នកកម្មវិធីខ្មែរ។ រក្សាសិទ្ធិគ្រប់យ៉ាង
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
