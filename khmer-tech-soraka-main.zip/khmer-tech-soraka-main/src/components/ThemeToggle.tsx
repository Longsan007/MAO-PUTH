
import React from "react";
import { Button } from "./ui/button";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "./ThemeProvider";

const ThemeToggle: React.FC = () => {
  const { theme, setTheme } = useTheme();
  
  return (
    <Button
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      variant="ghost"
      size="icon"
      className="rounded-full w-9 h-9 transition-all duration-300 hover:scale-110"
      aria-label="បិទ/បើកពន្លឺ"
    >
      {theme === "dark" ? (
        <Sun className="h-5 w-5 text-khmer-gold" />
      ) : (
        <Moon className="h-5 w-5" />
      )}
    </Button>
  );
};

export default ThemeToggle;
