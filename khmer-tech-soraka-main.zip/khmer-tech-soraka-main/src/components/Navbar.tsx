
import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import ThemeToggle from "./ThemeToggle";
import { Button } from "./ui/button";
import { Menu, X } from "lucide-react";

const NavLinks = [
  { path: "/", name: "ទំព័រដើម" },
  { path: "/about", name: "អំពីខ្ញុំ" },
  { path: "/skills", name: "ជំនាញរបស់ខ្ញុំ" },
  { path: "/projects", name: "គម្រោងរបស់ខ្ញុំ" },
  { path: "/blog", name: "ប្លក់បុគ្គលិក" },
  { path: "/contact", name: "ទំនាក់ទំនងខ្ញុំ" },
];

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className="bg-background/95 backdrop-blur-sm sticky top-0 z-30 w-full border-b border-khmer-gold/20">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="font-bold text-xl text-khmer-gold">
            អ្នកកម្មវិធីខ្មែរ
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {NavLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`nav-link ${
                  location.pathname === link.path ? "active" : ""
                }`}
              >
                {link.name}
              </Link>
            ))}
            <div className="ml-4">
              <ThemeToggle />
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center">
            <ThemeToggle />
            <Button
              variant="ghost"
              size="icon"
              className="ml-2"
              onClick={toggleMenu}
              aria-label={isOpen ? "បិទម៉ឺនុយ" : "បើកម៉ឺនុយ"}
            >
              {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-background/98 backdrop-blur-sm border-t border-khmer-gold/20">
          <div className="px-2 pt-2 pb-4 space-y-1">
            {NavLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`block px-3 py-2 rounded-md ${
                  location.pathname === link.path
                    ? "bg-primary/10 text-primary"
                    : "hover:bg-secondary"
                }`}
                onClick={() => setIsOpen(false)}
              >
                {link.name}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
