
import React, { useState } from "react";
import { Link } from "react-router-dom";

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  coverImage: string;
  date: string;
  readingTime: string;
  category: string;
}

interface BlogPostCardProps {
  post: BlogPost;
  animationDelay?: number;
}

const MAX_EXCERPT = 120; // Number of Khmer chars before truncation

const BlogPostCard: React.FC<BlogPostCardProps> = ({
  post,
  animationDelay = 0,
}) => {
  const [expanded, setExpanded] = useState(false);

  // Khmer-friendly excerpt (accounts for potential multi-byte glyphs)
  const needTruncate = post.excerpt.length > MAX_EXCERPT;
  const shownText =
    !needTruncate || expanded
      ? post.excerpt
      : post.excerpt.slice(0, MAX_EXCERPT) + "…";

  return (
    <div
      className="khmer-card overflow-hidden flex flex-col hover:shadow-lg transition-shadow animate-fade-in group"
      style={{ animationDelay: `${animationDelay}s` }}
    >
      <div className="aspect-video overflow-hidden rounded-md bg-white/60 dark:bg-[#111112]/70 group-hover:ring-2 group-hover:ring-khmer-gold/40">
        <img
          src={post.coverImage}
          alt={post.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="p-5 flex-grow">
        <div className="flex justify-between items-center mb-2 text-sm text-muted-foreground font-khmer">
          <span className="bg-primary/10 border border-primary/20 px-2 py-0.5 rounded-full">
            {post.category}
          </span>
          <span>{post.date}</span>
        </div>
        <h3 className="font-bold text-xl mb-3 font-khmer">{post.title}</h3>
        <p
          className="text-muted-foreground mb-4 font-khmer leading-loose"
          style={{ fontFamily: "'Kantumruy Pro', sans-serif" }}
        >
          {shownText}
        </p>
        {needTruncate && !expanded && (
          <button
            className="khmer-button px-4 py-1 mt-2 text-sm font-khmer"
            aria-label="អានបន្ថែម"
            style={{
              background:
                "linear-gradient(90deg, #d4af37 0%, #f7e7a3 100%)",
              color: "#1a1a1a",
            }}
            onClick={() => setExpanded(true)}
          >
            អានបន្ថែម
          </button>
        )}
        {needTruncate && expanded && (
          <button
            className="khmer-button px-4 py-1 mt-2 text-sm font-khmer"
            aria-label="បិទអត្ថបទ"
            style={{
              background:
                "linear-gradient(90deg, #f0ece3 0%, #b9972b 100%)",
              color: "#1a1a1a",
            }}
            onClick={() => setExpanded(false)}
          >
            បិទ
          </button>
        )}
      </div>
      <div className="p-5 pt-0 border-t border-khmer-gold/20 mt-auto font-khmer">
        <div className="flex justify-between items-center">
          <span className="text-sm">{post.readingTime}</span>
          <Link
            to={`/blog/${post.id}`}
            className="text-sm font-medium text-khmer-gold hover:underline"
            aria-label="ចូលទៅកាន់អត្ថបទពេញ"
            style={{
              fontFamily: "'Kantumruy Pro', sans-serif",
              textDecorationThickness: "2px",
            }}
          >
            ចូលអានអត្ថបទ
          </Link>
        </div>
      </div>
    </div>
  );
};

export default BlogPostCard;

