
import React from "react";

interface PageHeaderProps {
  title: string;
  description?: string;
}

const PageHeader: React.FC<PageHeaderProps> = ({ title, description }) => {
  return (
    <div className="temple-header mb-8">
      <h1 className="page-title animate-fade-in">{title}</h1>
      {description && <p className="text-muted-foreground max-w-2xl mx-auto text-center">{description}</p>}
    </div>
  );
};

export default PageHeader;
