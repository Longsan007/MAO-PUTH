
import React from "react";

const HomePage: React.FC = () => {
  return (
    <div>
      <div className="relative h-[70vh] overflow-hidden bg-khmer-indigo/40 dark:bg-khmer-indigo/80 flex items-center">
        <div 
          className="absolute inset-0 z-0 bg-cover bg-center opacity-30 dark:opacity-20"
          style={{ backgroundImage: "url('https://source.unsplash.com/photo-1469474968028-56623f02e42e')" }}
        />
        <div className="container mx-auto px-4 z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
              <span className="bg-gradient-to-r from-khmer-gold to-khmer-red bg-clip-text text-transparent">
                សូមស្វាគមន៍!
              </span>
            </h1>
            <p className="text-lg md:text-xl mb-8 animate-fade-in" style={{ animationDelay: "0.2s" }}>
              នៅលើគេហទំព័រអ្នកកម្មវិធីកម្ពុជា ជាកន្លែងដែលវប្បធម៌បុរាណជួបជាមួយបច្ចេកវិទ្យាទំនើប
            </p>
            <div className="animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <p className="text-base md:text-lg italic p-4 rounded-lg border border-khmer-gold/30 bg-background/60 backdrop-blur-sm mb-8">
                "កូដនិងវប្បធម៌ ដូចជាសរសៃឈាមដែលហូរតាមសាច់ដុំរបស់យើង៖ ជាការតភ្ជាប់ប្រវត្តិសាស្ត្រ និងអនាគត។"
              </p>
              <div className="flex justify-center">
                <a 
                  href="#scroll-down" 
                  className="khmer-button"
                >
                  សូមស្វាគមន៍មកកាន់បទពិសោធន៍
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div id="scroll-down" className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-center">
            <span className="border-b-2 border-khmer-gold pb-2">
              អ្វីដែលអ្នកនឹងរកឃើញនៅទីនេះ
            </span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <div className="khmer-card p-6 animate-scale-in" style={{ animationDelay: "0.1s" }}>
              <h3 className="font-bold text-xl mb-3 text-khmer-gold">ជំនាញនិងបទពិសោធន៍</h3>
              <p>ស្វែងយល់ពីការធ្វើដំណើររបស់អ្នកកម្មវិធី និងជំនាញបច្ចេកទេសដែលបានអភិវឌ្ឍក្នុងរយៈពេលជាច្រើនឆ្នាំ។</p>
            </div>
            
            <div className="khmer-card p-6 animate-scale-in" style={{ animationDelay: "0.2s" }}>
              <h3 className="font-bold text-xl mb-3 text-khmer-gold">គម្រោងដែលបានបង្កើត</h3>
              <p>រកមើលគម្រោងបច្ចេកវិទ្យាដែលបានបង្កើតជាមួយជំនាញបច្ចេកទេស និងស្នាដៃច្នៃប្រឌិតនានា។</p>
            </div>
            
            <div className="khmer-card p-6 animate-scale-in" style={{ animationDelay: "0.3s" }}>
              <h3 className="font-bold text-xl mb-3 text-khmer-gold">ការបង្ហាញចំនេះដឹងនិងបទពិសោធន៍</h3>
              <p>អានអត្ថបទប្លក់ស្ដីអំពីបច្ចេកវិទ្យា ជីវិត វប្បធម៌ និងបទពិសោធន៍ផ្ទាល់ខ្លួនជាអ្នកអភិវឌ្ឍន៍កម្ពុជា។</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="py-16 px-4 bg-primary/5">
        <div className="container mx-auto">
          <div className="khmer-pattern-border p-8 rounded-lg max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-4 text-center">ជាមួយប្រពៃណីខ្មែរក្នុងបច្ចេកវិទ្យាទំនើប</h2>
            <p className="mb-4">
              គេហទំព័រនេះបានរចនាឡើងដើម្បីបង្ហាញពីការរួមបញ្ចូលប្រពៃណីនិងវប្បធម៌ខ្មែរដ៏ស្រស់ស្អាតជាមួយនឹងចំណេះដឹងផ្នែកបច្ចេកវិទ្យា។ 
              យើងជឿថាសិល្បៈបុរាណអាចជម្រុញនវានុវត្តន៍ទំនើបបាន។
            </p>
            <p>
              តាមរយៈការច្នៃប្រឌិតលក្ខណៈពិសេសនៃការរចនាបែបប្រពៃណី និងរូបភាពដូចជាអង្គរវត្ត កាច់រចនាបែបខ្មែរ និងរូបចម្លាក់ 
              យើងពង្រីកបេតិកភណ្ឌវប្បធម៌របស់យើងឱ្យរស់នៅក្នុងពិភពឌីជីថល។
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
