
import React from "react";
import PageHeader from "@/components/PageHeader";

interface Skill {
  name: string;
  level: number;
  category: string;
}

const SkillsPage: React.FC = () => {
  const skills: Skill[] = [
    // Frontend
    { name: "HTML", level: 90, category: "ផ្នែកខាងមុខ" },
    { name: "CSS", level: 85, category: "ផ្នែកខាងមុខ" },
    { name: "JavaScript", level: 85, category: "ផ្នែកខាងមុខ" },
    { name: "React", level: 80, category: "ផ្នែកខាងមុខ" },
    { name: "TypeScript", level: 75, category: "ផ្នែកខាងមុខ" },
    
    // Backend
    { name: "Node.js", level: 80, category: "ផ្នែកខាងក្រោយ" },
    { name: "Python", level: 75, category: "ផ្នែកខាងក្រោយ" },
    { name: "PHP", level: 65, category: "ផ្នែកខាងក្រោយ" },
    { name: "MongoDB", level: 70, category: "ផ្នែកខាងក្រោយ" },
    { name: "MySQL", level: 75, category: "ផ្នែកខាងក្រោយ" },
    
    // DevOps
    { name: "Docker", level: 60, category: "DevOps" },
    { name: "Git", level: 85, category: "DevOps" },
    { name: "GitHub Actions", level: 65, category: "DevOps" },
    
    // Languages
    { name: "ភាសាខ្មែរ", level: 100, category: "ភាសា" },
    { name: "ភាសាអង់គ្លេស", level: 75, category: "ភាសា" },
  ];

  const categories = [...new Set(skills.map((skill) => skill.category))];

  return (
    <div className="container mx-auto px-4 py-12">
      <PageHeader
        title="ជំនាញរបស់ខ្ញុំ"
        description="បច្ចេកទេសនិងសមត្ថភាពដែលខ្ញុំបានអភិវឌ្ឍក្នុងអាជីពរបស់ខ្ញុំ"
      />

      <div className="max-w-4xl mx-auto">
        {categories.map((category, index) => (
          <div key={category} className="mb-12 animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
            <h2 className="text-2xl font-bold mb-6 text-center">
              <span className="border-b-2 border-khmer-gold pb-2">
                {category}
              </span>
            </h2>
            <div className="grid grid-cols-1 gap-6">
              {skills
                .filter((skill) => skill.category === category)
                .map((skill) => (
                  <div key={skill.name} className="khmer-card p-6">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">{skill.name}</span>
                      <span className="text-sm text-muted-foreground">{skill.level}%</span>
                    </div>
                    <div className="skill-bar">
                      <div 
                        className="skill-progress"
                        style={{ 
                          width: `${skill.level}%`, 
                          transitionDelay: "0.5s" 
                        }}
                      ></div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        ))}

        <div className="khmer-divider"></div>

        <div className="khmer-pattern-border p-6 rounded-lg mt-12">
          <h2 className="text-2xl font-bold mb-4 text-center text-khmer-gold">ជំនាញផ្សេងៗទៀត</h2>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-4 list-disc list-inside">
            <li>ការគ្រប់គ្រងគម្រោង</li>
            <li>ការវិភាគទិន្នន័យ</li>
            <li>ការរចនាគំនូរ UI/UX</li>
            <li>ការធ្វើតេស្តសូហ្វវែរ</li>
            <li>ការបង្កើតអាជីវកម្មឌីជីថល</li>
            <li>ការទំនាក់ទំនងប្រកបដោយប្រសិទ្ធភាព</li>
            <li>ការដោះស្រាយបញ្ហា</li>
            <li>ការគិតជាប្រព័ន្ធ</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default SkillsPage;
