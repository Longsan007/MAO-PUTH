
import React, { useState } from "react";
import { Facebook, Linkedin, MessageCircle } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";

const ContactPage: React.FC = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      toast({
        title: "បានផ្ញើសារដោយជោគជ័យ",
        description: "អរគុណសម្រាប់ការទំនាក់ទំនង។ ខ្ញុំនឹងឆ្លើយតបឆាប់ៗនេះ។",
      });
      setFormData({ name: "", email: "", message: "" });
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <PageHeader
        title="ទំនាក់ទំនងខ្ញុំ"
        description="មានសំណួរឬចង់ធ្វើការជាមួយគ្នា? សូមទាក់ទងមកខ្ញុំ"
      />

      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="khmer-card p-6">
            <h2 className="font-bold text-xl mb-6">ផ្ញើសារមកខ្ញុំ</h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="name" className="block mb-1">
                  ឈ្មោះ
                </label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full"
                  placeholder="សូមបញ្ចូលឈ្មោះរបស់អ្នក"
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="email" className="block mb-1">
                  អ៊ីមែល
                </label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full"
                  placeholder="អ៊ីមែលរបស់អ្នក"
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="message" className="block mb-1">
                  សារ
                </label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full"
                  placeholder="សូមសរសេរសាររបស់អ្នកនៅទីនេះ..."
                />
              </div>
              
              <Button 
                type="submit" 
                className="khmer-button w-full" 
                disabled={isSubmitting}
              >
                {isSubmitting ? "កំពុងផ្ញើ..." : "ផ្ញើសារ"}
              </Button>
            </form>
          </div>
          
          <div className="flex flex-col gap-6">
            <div className="khmer-card p-6">
              <h2 className="font-bold text-xl mb-4">ព័ត៌មានទំនាក់ទំនង</h2>
              <div className="space-y-3">
                <p>
                  <span className="font-medium">អ៊ីមែល:</span> contact@example.com
                </p>
                <p>
                  <span className="font-medium">ទីតាំង:</span> ក្រុងភ្នំពេញ, កម្ពុជា
                </p>
              </div>
            </div>
            
            <div className="khmer-card p-6 flex-grow">
              <h2 className="font-bold text-xl mb-4">បណ្ដាញសង្គម</h2>
              <div className="space-y-4">
                <a 
                  href="#" 
                  className="flex items-center gap-3 p-3 bg-background hover:bg-primary/5 rounded-md transition-colors"
                >
                  <Facebook className="h-6 w-6" />
                  <span>អ្នកកម្មវិធីកម្ពុជា - Facebook</span>
                </a>
                
                <a 
                  href="#" 
                  className="flex items-center gap-3 p-3 bg-background hover:bg-primary/5 rounded-md transition-colors"
                >
                  <Linkedin className="h-6 w-6" />
                  <span>អ្នកកម្មវិធីកម្ពុជា - LinkedIn</span>
                </a>
                
                <a 
                  href="#" 
                  className="flex items-center gap-3 p-3 bg-background hover:bg-primary/5 rounded-md transition-colors"
                >
                  <MessageCircle className="h-6 w-6" />
                  <span>អ្នកកម្មវិធីកម្ពុជា - Telegram</span>
                </a>
              </div>
            </div>
            
            <div className="khmer-pattern-border p-6 text-center">
              <p className="italic">
                "ការអភិវឌ្ឍន៍បច្ចេកវិទ្យាគឺការរក្សាប្រពៃណីខ្មែរយ៉ាងប្រណិតក្នុងសតវត្សថ្មី"
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
