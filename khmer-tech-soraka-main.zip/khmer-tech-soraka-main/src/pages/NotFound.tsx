
import React from "react";
import { Link } from "react-router-dom";

const NotFound: React.FC = () => {
  return (
    <div className="min-h-[70vh] flex items-center justify-center">
      <div className="khmer-pattern-border p-8 rounded-lg max-w-md mx-auto text-center">
        <h1 className="text-6xl font-bold mb-4 text-khmer-gold">៤០៤</h1>
        <p className="text-xl mb-6">គេហទំព័រដែលអ្នកកំពុងស្វែងរកមិនមានទេ</p>
        <Link to="/" className="khmer-button">
          ត្រឡប់ទៅទំព័រដើម
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
