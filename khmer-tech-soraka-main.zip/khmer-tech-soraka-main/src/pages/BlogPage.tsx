import React from "react";
import PageHeader from "@/components/PageHeader";
import BlogPostCard from "@/components/BlogPostCard";

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  coverImage: string;
  date: string;
  readingTime: string;
  category: string;
}

const BlogPage: React.FC = () => {
  const blogPosts: BlogPost[] = [
    {
      id: "1",
      title: "ការវិវឌ្ឍន៍នៃបច្ចេកវិទ្យាក្នុងការអប់រំនៅកម្ពុជា",
      excerpt:
        "បច្ចេកវិទ្យាបានចូលរួមយ៉ាងសំខាន់ក្នុងការផ្លាស់ប្តូរវិស័យអប់រំនៅកម្ពុជា ហើយបានបង្កើតឱកាសថ្មីៗសម្រាប់សិស្សានុសិស្សដើម្បីទទួលបានចំណេះដឹងបានកាន់តែងាយស្រួល។",
      coverImage: "https://source.unsplash.com/photo-1488190211105-8b0e65b80b4e",
      date: "១០ កុម្ភៈ ២០២៥",
      readingTime: "៥ នាទី",
      category: "ការអប់រំ",
    },
    {
      id: "2",
      title: "អនាគតនៃការអភិវឌ្ឍសូហ្វវែរនៅកម្ពុជា",
      excerpt:
        "ការអភិវឌ្ឍកម្មវិធីកំពុងកើនឡើងនៅកម្ពុជា ហើយវាអាចរួមចំណែកដល់សេដ្ឋកិច្ចឌីជីថលរបស់ប្រទេស។ តើការអភិវឌ្ឍសូហ្វវែរនាអនាគតនឹងដូចម្តេច?",
      coverImage: "https://source.unsplash.com/photo-1531403009284-440f080d1e12",
      date: "២២ មករា ២០២៥",
      readingTime: "៧ នាទី",
      category: "បច្ចេកវិទ្យា",
    },
    {
      id: "3",
      title: "រឿងព្រេងនិទានខ្មែរក្នុងពិភពឌីជីថល",
      excerpt:
        "របៀបដែលរឿងព្រេងនិទានខ្មែរបុរាណអាចត្រូវបានធ្វើទំនើបកម្មនិងថែរក្សាតាមរយៈបច្ចេកវិទ្យាឌីជីថល ដើម្បីបន្តការចែករំលែកឱ្យក្មេងជំនាន់ក្រោយ។",
      coverImage: "https://source.unsplash.com/photo-1433086966358-54859d0ed716",
      date: "៥ ធ្នូ ២០២៤",
      readingTime: "៦ នាទី",
      category: "វប្បធម៌",
    },
    {
      id: "4",
      title: "ការប្រឈមនៃអ្នកអភិវឌ្ឍន៍កម្មវិធីនៅកម្ពុជា",
      excerpt:
        "ការលំបាកដែលអ្នកអភិវឌ្ឍន៍កម្មវិធីកម្ពុជាជួបប្រទះ និងរបៀបដែលពួកគេអាចជំនះបញ្ហាប្រឈមទាំងនោះ ដើម្បីរីកចម្រើននៅក្នុងឧស្សាហកម្មនេះ។",
      coverImage: "https://source.unsplash.com/photo-1516321318423-f06f85e504b3",
      date: "១៨ វិច្ឆិកា ២០២៤",
      readingTime: "៨ នាទី",
      category: "បទពិសោធន៍",
    },
    {
      id: "5",
      title: "ប្រាជ្ញាខ្មែរបុរាណក្នុងការសរសេរកូដ",
      excerpt:
        "របៀបដែលទស្សនៈវិជ្ជានិងគំនិតពីវប្បធម៌ខ្មែរបុរាណអាចត្រូវបានអនុវត្តក្នុងការសរសេរកូដនិងការអភិវឌ្ឍសូហ្វវែរ។",
      coverImage: "https://source.unsplash.com/photo-1470071459604-3b5ec3a7fe05",
      date: "៣០ តុលា ២០២៤",
      readingTime: "៤ នាទី",
      category: "ទស្សនៈវិជ្ជា",
    },
    {
      id: "6",
      title: "បច្ចេកវិទ្យាបុរាណខ្មែរអាចបង្រៀនយើងអ្វីខ្លះ",
      excerpt:
        "សិល្បៈនិងបច្ចេកវិទ្យាបុរាណរបស់ខ្មែរ ដូចជាប្រាសាទអង្គរវត្ត អាចជាប្រភពនៃការបំផុសគំនិតសម្រាប់អ្នកអភិវឌ្ឍន៍កម្មវិធីសម័យទំនើប។",
      coverImage: "https://source.unsplash.com/photo-1466442929976-97f336a657be",
      date: "១២ កញ្ញា ២០២៤",
      readingTime: "៦ នាទី",
      category: "វប្បធម៌",
    },
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      <PageHeader
        title="ប្លក់បុគ្គលិក"
        description="គំនិតនិងចំណេះដឹងស្តីពីបច្ចេកវិទ្យា វប្បធម៌ និងជីវិតនៅកម្ពុជា"
      />
      <div className="max-w-5xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {blogPosts.map((post, idx) => (
            <BlogPostCard
              key={post.id}
              post={post}
              animationDelay={idx * 0.1}
            />
          ))}
        </div>

        <div className="khmer-divider my-10"></div>

        <div className="khmer-pattern-border p-6 rounded-lg max-w-3xl mx-auto text-center">
          <h3 className="font-bold text-xl mb-3 font-khmer">
            ការប្រើប្រាស់រឿងព្រេងខ្មែរក្នុងការកូដ
          </h3>
          <p className="mb-4 font-khmer">
            "សូម្បីតែមេរៀនពិបាកនៃការកូដក៏អាចយល់បានកាន់តែងាយស្រួល ពេលប្រៀបធៀបជាមួយនឹងរឿងព្រេងនិទានខ្មែរ។ ដូចជារឿង ព្រះជិនរាជចម្លងអក្សរ ដែលបង្រៀនយើងពីសារៈសំខាន់នៃការចម្លងឯកសារជាប្រព័ន្ធ និងការកែកំហុសដោយយកចិត្តទុកដាក់។"
          </p>
        </div>
      </div>
    </div>
  );
};

export default BlogPage;
