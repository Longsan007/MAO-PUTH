import React from "react";
import PageHeader from "@/components/PageHeader";
import { Github } from "lucide-react";

interface Project {
  name: string;
  description: string;
  techStack: string[];
  image: string;
  githubLink: string;
  liveLink?: string;
}

const ProjectsPage: React.FC = () => {
  const projects: Project[] = [
    {
      name: "កម្មវិធីគ្រប់គ្រងសាលារៀន",
      description:
        "ប្រព័ន្ធគ្រប់គ្រងសាលារៀនដែលជួយពង្រឹងដល់ដំណើរការសិក្សាអប់រំនៅកម្ពុជា តាមរយៈការគ្រប់គ្រងសិស្ស គ្រូបង្រៀន និងកាលវិភាគសិក្សា។",
      techStack: ["React", "Node.js", "MongoDB", "Express"],
      image:
        "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&w=800&q=80",
      githubLink: "#",
      liveLink: "#",
    },
    {
      name: "វេបសាយមគ្គុទ្ទេសក៍ទេសចរណ៍កម្ពុជា",
      description:
        "បង្កើតវេបសាយណែនាំពីទេស ចរណ៍កម្ពុជា មានដូចជាព័ត៌មានពីកន្លែងទេស ចរណ៍ផ្សេងៗ ជាមួយនឹងផែនទី និងការណែនាំលម្អិត។",
      techStack: ["Angular", "TypeScript", "Firebase", "Google Maps API"],
      image:
        "https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=800&q=80",
      githubLink: "#",
    },
    {
      name: "កម្មវិធីបកប្រែភាសាខ្មែរ",
      description:
        "កម្មវិធីបកប្រែភាសាដោយប្រើបច្ចេកវិទ្យា AI ដែលអាចបកប្រែពីភាសាអង់គ្លេសទៅភាសាខ្មែរ និងពីភាសាខ្មែរទៅភាសាអង់គ្លេស។",
      techStack: ["Python", "TensorFlow", "Flask", "React"],
      image: "https://source.unsplash.com/photo-1456513080510-7bf3a84b82f8",
      githubLink: "#",
      liveLink: "#",
    },
    {
      name: "កម្មវិធីទិញលក់អនឡាញ",
      description:
        "បង្កើតកម្មវិធីទិញលក់អនឡាញសម្រាប់ផលិតផលក្នុងស្រុក ដើម្បីជួយដល់អាជីវកម្មខ្នាតតូចនៅកម្ពុជាឱ្យអាចលក់ផលិតផលរបស់ពួកគេតាមអ៊ិនធើនិត។",
      techStack: ["Next.js", "Node.js", "PostgreSQL", "Stripe"],
      image: "https://source.unsplash.com/photo-1556742502-ec7c0e9f34b1",
      githubLink: "#",
    },
    {
      name: "កម្មវិធីរៀនភាសាខ្មែរ",
      description:
        "កម្មវិធីរៀនភាសាខ្មែរសម្រាប់ជនបរទេស មានមេរៀន លំហាត់ និងការស្ដាប់ការបញ្ចេញសម្លេង។",
      techStack: ["React Native", "Redux", "Firebase"],
      image: "https://source.unsplash.com/photo-1503676260728-1c00da094a0b",
      githubLink: "#",
      liveLink: "#",
    },
    {
      name: "កម្មវិធីអាន-ស្ដាប់កំណាព្យខ្មែរ",
      description:
        "កម្មវិធីស្ដាប់និងអានកំណាព្យខ្មែរ ជាមួយការពន្យល់ពាក្យពេចន៍ និងប្រវត្តិនៃកំណាព្យនីមួយៗ។",
      techStack: ["Vue.js", "Vuetify", "Node.js", "MongoDB"],
      image: "https://source.unsplash.com/photo-1506880018603-83d5b814b5a6",
      githubLink: "#",
    },
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      <PageHeader
        title="គម្រោងរបស់ខ្ញុំ"
        description="គម្រោងផ្សេងៗដែលខ្ញុំបានបង្កើតឡើង"
      />

      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={project.name}
              className="project-card overflow-hidden flex flex-col relative animate-scale-in group"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="aspect-video overflow-hidden rounded-2xl mb-4 shadow-sm border border-khmer-gold/10 bg-white/80 dark:bg-[#18181a]/80 transition-all duration-300 group-hover:shadow-lg group-hover:ring-2 group-hover:ring-khmer-gold/40">
                <img
                  src={project.image}
                  alt={project.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  style={{
                    filter: index === 0
                      ? "saturate(1.1) brightness(1.02) drop-shadow(0 8px 16px #d4af3740)"
                      : undefined,
                  }}
                />
                <div className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-60 transition-opacity rounded-2xl"
                  style={{
                    background:
                      "radial-gradient(circle, rgba(212,175,55,0.14) 60%, transparent 100%)",
                  }}
                />
              </div>
              <h3 className="font-bold text-xl mb-2 font-khmer" style={{ fontFamily: "'Kantumruy Pro', sans-serif" }}>
                {project.name}
              </h3>
              <p className="text-muted-foreground mb-4 flex-grow font-khmer"
                style={{ fontFamily: "'Kantumruy Pro', sans-serif" }}>
                {project.description}
              </p>
              <div className="mt-auto">
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.techStack.map((tech) => (
                    <span
                      key={tech}
                      className="text-xs px-2 py-1 rounded-full bg-primary/10 border border-primary/20 font-khmer"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                <div className="flex gap-3">
                  <a
                    href={project.githubLink}
                    className="khmer-button text-sm font-khmer"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Github className="mr-1 h-4 w-4" /> កូដប្រភព
                  </a>
                  {project.liveLink && (
                    <a
                      href={project.liveLink}
                      className="khmer-button text-sm font-khmer"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      មើលគម្រោង
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProjectsPage;
