
import React from "react";
import ProfileSection from "@/components/ProfileSection";
import PageHeader from "@/components/PageHeader";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";

const AboutPage: React.FC = () => {
  return (
    <div className="flex flex-col items-stretch w-full">
      <ProfileSection />
      <main className="container mx-auto px-4 py-6 max-w-3xl">
        <section className="about-me mb-8">
          <h2
            className="text-2xl md:text-3xl font-bold mb-4 mt-2 text-center text-khmer-gold font-khmer"
            style={{ fontFamily: "'Kantumruy Pro', sans-serif" }}
          >
            អំពីខ្ញុំ
          </h2>
          <div className="khmer-card p-6 rounded-lg shadow-lg">
            <p
              className="font-khmer text-base md:text-lg mb-4 leading-relaxed"
              style={{ fontFamily: "'Kantumruy Pro', sans-serif", lineHeight: 1.8 }}
            >
              សួស្ដី! ខ្ញុំឈ្មោះ ជា សុភា។ ខ្ញុំជាអ្នកបង្កើតកម្មវិធីម្នាក់ដែលកើតនិងធំឡើងនៅក្នុងខេត្តសៀមរាប។ ចាប់តាំងពីខ្ញុំមានអាយុ ១៥ឆ្នាំ ខ្ញុំបានចាប់ផ្តើមស្វែងយល់ពីភាសាកូដតាមបណ្ដាញហើយស្រលាញ់វាដូចជាសិល្បៈ។ ការរចនាអ្នកប្រើប្រាស់ និងបង្កើតប្រព័ន្ធដែលអាចជួយឲ្យមនុស្សធ្វើការ បានកាន់តែងាយស្រួល ជាគោលដៅនៃជីវិតខ្ញុំ។
            </p>
            <p
              className="font-khmer text-base md:text-lg mb-4"
              style={{ fontFamily: "'Kantumruy Pro', sans-serif" }}
            >
              ខ្ញុំជឿជាក់ថា បច្ចេកវិទ្យាគួរតែចែករំលែក និងជួយលើកកម្ពស់ជីវិតមនុស្ស។ ខ្ញុំចូលចិត្តរចនាកូដស្អាត មានប្រសិទ្ធភាព និងអាចរក្សា ប្រើបានយូរ។ ខ្ញុំបានធ្វើការជាមួយ Startup ក្នុងទីក្រុងភ្នំពេញ និងបច្ចុប្បន្នកំពុងសហការជាមួយក្រុមអ្នកអភិវឌ្ឍនៅតាមពិភពលោក។
            </p>
          </div>
          
          <div className="khmer-divider my-10"></div>
          
          <h2
            className="text-2xl md:text-3xl font-bold mb-4 mt-8 text-center text-khmer-gold font-khmer"
          >
            ជំនាញរបស់ខ្ញុំ
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <HoverCard openDelay={200}>
              <HoverCardTrigger asChild>
                <div className="khmer-card p-4 text-center cursor-pointer transition-all hover:scale-105">
                  <h3 className="font-bold text-lg mb-2 text-khmer-gold">ការអភិវឌ្ឍខាងមុខ</h3>
                  <p className="font-khmer">React, Vue, Angular, និង TypeScript</p>
                </div>
              </HoverCardTrigger>
              <HoverCardContent className="w-80">
                <div className="font-khmer">
                  <h4 className="font-bold">ការអភិវឌ្ឍខាងមុខ</h4>
                  <p>៤ឆ្នាំនៃបទពិសោធន៍ក្នុងការបង្កើតអន្តរមុខអ្នកប្រើប្រាស់ដែលឆ្លាតវៃ និងមានចលនា</p>
                </div>
              </HoverCardContent>
            </HoverCard>
            
            <HoverCard openDelay={200}>
              <HoverCardTrigger asChild>
                <div className="khmer-card p-4 text-center cursor-pointer transition-all hover:scale-105">
                  <h3 className="font-bold text-lg mb-2 text-khmer-gold">ការអភិវឌ្ឍខាងក្រោយ</h3>
                  <p className="font-khmer">Node.js, Python, និង MongoDB</p>
                </div>
              </HoverCardTrigger>
              <HoverCardContent className="w-80">
                <div className="font-khmer">
                  <h4 className="font-bold">ការអភិវឌ្ឍខាងក្រោយ</h4>
                  <p>បទពិសោធន៍ជាមួយ API, សន្តិសុខ និងការគ្រប់គ្រងទិន្នន័យ</p>
                </div>
              </HoverCardContent>
            </HoverCard>
            
            <HoverCard openDelay={200}>
              <HoverCardTrigger asChild>
                <div className="khmer-card p-4 text-center cursor-pointer transition-all hover:scale-105">
                  <h3 className="font-bold text-lg mb-2 text-khmer-gold">គំនូរនិងរចនា</h3>
                  <p className="font-khmer">Figma, Adobe XD និង Photoshop</p>
                </div>
              </HoverCardTrigger>
              <HoverCardContent className="w-80">
                <div className="font-khmer">
                  <h4 className="font-bold">គំនូរនិងរចនា</h4>
                  <p>ការរចនាប្លង់ផ្ដោតលើបទពិសោធន៍អ្នកប្រើប្រាស់ល្អបំផុត</p>
                </div>
              </HoverCardContent>
            </HoverCard>
            
            <HoverCard openDelay={200}>
              <HoverCardTrigger asChild>
                <div className="khmer-card p-4 text-center cursor-pointer transition-all hover:scale-105">
                  <h3 className="font-bold text-lg mb-2 text-khmer-gold">ការគ្រប់គ្រងគម្រោង</h3>
                  <p className="font-khmer">Agile, Scrum និង Jira</p>
                </div>
              </HoverCardTrigger>
              <HoverCardContent className="w-80">
                <div className="font-khmer">
                  <h4 className="font-bold">ការគ្រប់គ្រងគម្រោង</h4>
                  <p>ការដឹកនាំក្រុមនិងការសម្របសម្រួលគម្រោងប្រកបដោយប្រសិទ្ធភាព</p>
                </div>
              </HoverCardContent>
            </HoverCard>
          </div>
          
          <div className="mt-12">
            <p
              className="font-khmer text-base md:text-lg mb-2 italic text-center"
              style={{ fontFamily: "'Kantumruy Pro', sans-serif", color: "#d4af37" }}
            >
              "កូដគឺជាសិល្បៈដែលនាំអោយការច្នៃប្រឌិតក្លាយជាការពិត។"
            </p>
          </div>
        </section>
      </main>
    </div>
  );
};

export default AboutPage;
