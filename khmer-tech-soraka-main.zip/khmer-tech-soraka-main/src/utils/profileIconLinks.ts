
import { Mail, Send, Phone, Github, Facebook } from "lucide-react";
import { LucideIcon } from "lucide-react";

type ProfileIconLink = {
  href: string;
  icon: LucideIcon;
  label: string;
};

export const ICON_LINKS: ProfileIconLink[] = [
  {
    href: "mailto:sophea@example.com",
    icon: Mail,
    label: "អ៊ីមែល"
  },
  {
    href: "tel:+85512345678",
    icon: Phone,
    label: "ទូរស័ព្ទ"
  },
  {
    href: "https://github.com/sopheakhmer",
    icon: Github,
    label: "GitHub"
  },
  {
    href: "https://facebook.com/sophea.kh",
    icon: Facebook,
    label: "Facebook"
  },
  {
    href: "https://t.me/sophea_telegram",
    icon: Send,
    label: "Telegram"
  },
];
